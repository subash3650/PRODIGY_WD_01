# PRODIGY_WD_01
This code is for the submission of Task 1 for Prodigy InfoTech Internship.
It is an responsive navigation bar which changes colour over the hover of the mouse
.It has the dark mode option to change the light to dark mode
